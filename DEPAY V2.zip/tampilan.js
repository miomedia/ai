/*
Developer: Depay Ganteng
Ini tampilan bot nya,boleh di rename dll
jangan di jual ye

jangan hapus web developer untuk menghargai Gweh yang udah bikin jing
webdev : https://depay.dev 
*/
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
const speed = require('performance-now');

exports.WelcomeMenuDepay = async (depayy, m, pushname, runtime, qtext) => {
    const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
    let timestamp = speed();
    let latensi = speed() - timestamp;
    //Teks
    let teks = `Welcome back, *${pushname}*.
    
Hi, I'm a bot created by \`ᗪΞᎮᗑƔ\` , This bot is specifically designed to attack, manage groups, provide useful tools, offer fun interactions, and help you create panels. Use this bot wisely; it is strictly prohibited to use these features to harm others.

—  *INFORMATION* —
Release: *2.0* 
Developer: *Depay*
GetScript: https://depay.dev
Youtube: @DepayAsli
Telegram: @DepayAsli
Tiktok: @payeyeye_
Runtime: ${runtime(process.uptime())}
SpeedBot : ${latensi.toFixed(4)} detik


— Thank you for using this bot :>
`
    const headerImage = await prepareWAMessageMedia(
        { image: { url: "https://depay.dev/foto.jpeg" } },
        { upload: depayy.waUploadToServer }
    );

    const interactiveMessage = proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
            text: teks
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
            text: `\`⚝ ᗪΞᎮᗑƔ - OFFICIAL\``
        }),
        header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            hasMediaAttachment: true,
            imageMessage: headerImage.imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
                limited_time_offer: {
                    text: "⚝ ᗪΞᎮᗑƔ - OFFICIAL",
                    url: "https://depay.dev",
                    copy_code: "https://depay.dev",
                    expiration_time: Date.now() * 999
                },
                bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "⚝ ᗪΞᎮᗑƔ - DEV",
                    button_title: "⚝ ᗪΞᎮᗑƔ "
                },
                tap_isTarget_configuration: {
                    title: " X ",
                    description: "bomboclard",
                    canonical_url: "https://depay.dev",
                    domain: "https://depay.dev",
                    button_index: 0
                }
            }),
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "— YouTube —",
                        url: "https://youtube.com/@DepayAsli"
                    })
                },
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "— Show Fiture —",
                        sections: [
                            {
                                title: "— Public Fiture —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".allmnu"
                                }]
                            }, 
                            {
                                title: "— Command Private —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".bvgmenu"
                                }]
                            }, 
                            {
                                title: "— Contact Developer —",
                                rows: [{
                                    title: "Kontak Dev",
                                    description: "© DepayDeveloper",
                                    id: ".dev"
                                }]
                            }, 
                            {
                                title: "— Credit Script —",
                                rows: [{
                                    title: "Spesial Support",
                                    description: "© DepayDeveloper",
                                    id: ".tqto"
                                }]
                            }
                        ]
                    })
                },
                {
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Website Dev —", 
                        url: "https://depay.dev" 
                    }) 
                },
                { 
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Info Script —", 
                        url: "https://whatsapp.com/channel/0029Vb7zxXq7oQhl0tOf7417" 
                    }) 
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "— Thank you for using this bot :>",
                        flow_message_version: "3"
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Developer: depay.dev ", //jangan di hapus
                        flow_message_version: "3"    
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Spesial Support: Aaiiurs🌻", //jangan di hapus
                        flow_message_version: "3"                
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "                            © depay.dev          ",
                        flow_message_version: "3"          
                    })
                }
            ]
        }),
        contextInfo: {
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: 'New ERA',
                body: 'Depay Official',
                previewType: 'VIDEO',
                thumbnailUrl: 'https://depay.dev/levi.jpg',
                sourceUrl: 'https://depay.dev'
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    });

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: interactiveMessage
            }
        }
    }, { 
        quoted: qtext 
    });

    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 {
 await new Promise(resolve => setTimeout(resolve, 1000));
        await depayy.sendMessage(m.chat, {
            audio: { url: "https://depay.dev/depaymusik.mp3" },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: '⚝ ᗪΞᎮᗑƔ - OFFICIAL',
                    body: '© Depayy',
                    thumbnailUrl: 'https://depay.dev/foto.jpeg',
                    sourceUrl: 'https://depay.dev',
                    mediaType: 1,
                    renderLargerThumbnail: false
                },
                ...qtext.contextInfo,
                quotedMessage: qtext.message
            }
        }, { 
            quoted: qtext
        });
    }
} 

//reply teks
exports.payreply = async (teks, lol, m, depayy, proto) => {
    let msgii = generateWAMessageFromContent(m.chat, { 
        viewOnceMessage: { 
            message: { 
                "messageContextInfo": { 
                    "deviceListMetadata": {}, 
                    "deviceListMetadataVersion": 2
                }, 
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: { 
                        mentionedJid: [m.sender], 
                        isForwarded: true,
                        forwardingScore: 999,
                        ...lol.contextInfo,
                        quotedMessage: lol.message,
                        externalAdReply: {
                            showAdAttribution: false,
                            title: 'Depay Official Notification',
                            body: 'V2.0 NEW ERA',
                            thumbnailUrl: 'https://depay.dev/levi.jpg',
                            sourceUrl: 'https://youtube.com/@DepayAsli'
                        }
                    }, 
                    body: proto.Message.InteractiveMessage.Body.create({ 
                        text: teks
                    }), 
                    footer: proto.Message.InteractiveMessage.Footer.create({ 
                        text: "\`⚝ ᗪΞᎮᗑƔ - OFFICIAL\`"
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                        buttons: [{
                            "name": "cta_url",
                            "buttonParamsJson": JSON.stringify({
                                "display_text": "Get Script!",
                                "url": "https://depay.dev",
                                "merchant_url": "https://www.google.com"
                            })
                        }]
                    }) 
                }) 
            } 
        } 
    }, { userJid: m.sender, quoted: lol });

    await depayy.relayMessage(msgii.key.remoteJid, msgii.message, { 
        messageId: msgii.key.id 
    });
}

//Tampilan 2
exports.MenuBotDepay2 = async (depayy, m, pushname, runtime, qtext) => {
    let timestamp = speed();
    let latensi = speed() - timestamp;
    let teks = `Welcome back, *${pushname}*.
    
Hi, I'm a bot created by \`ᗪΞᎮᗑƔ\` , This bot is specifically designed to attack, manage groups, provide useful tools, offer fun interactions, and help you create panels. Use this bot wisely; it is strictly prohibited to use these features to harm others.

—  *INFORMATION* —
Release: *2.0* 
Developer: *Depay*
Youtube: @DepayAsli
Type: case
Visibility: Global
Trigger: .
Library: Baileys
Github: depay1221 
Telegram: @DepayAsli
Tiktok: @payeyeye_
Action: https://ẉ.depay/dev
Runtime: ${runtime(process.uptime())}
🚀 : ${latensi.toFixed(4)} detik
GetScript: https://depay.dev

— *Forclose Android*
 .crash-invis - *Target*
 .crash-x - *Target*
 .infinity-crash - *Target*
 .hard-crash - *Target*
 .crash-xv1 - *Target*
 .forx-andro - *Target*
 .crashdep - *Target*

— *Delay Android*
 .delay-hard - *Target*
 .delay-invis - *Target*
 .delay-infinity - *Target*
 .delay-perma - *Target*
 .delay-buldo - *Target*

— *Forclose IOS*
 .crash-ios - *Target*
 .invis-ios - *Target*
 .force-ios - *Target*

— *Bug Group*
 .crashgb - *Link-Group*
 .bvggb - *Link-Group*
 .blankgb - *Link-Group*

— *Add Acces*
 .addprem *Number*
 .delprem *Number*
 .addowner *Number*
 .delowner *Number*
 .self
 .public
 ` 
    const headerImage = await prepareWAMessageMedia(
        { image: { url: "https://depay.dev/foto.jpeg" } },
        { upload: depayy.waUploadToServer }
    );

    const interactiveMessage = proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
            text: teks
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
            text: `\`⚝ ᗪΞᎮᗑƔ - OFFICIAL\``
        }),
        header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            hasMediaAttachment: true,
            imageMessage: headerImage.imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
                limited_time_offer: {
                    text: "⚝ ᗪΞᎮᗑƔ - OFFICIAL",
                    url: "https://depay.dev",
                    copy_code: "https://depay.dev",
                    expiration_time: Date.now() * 999
                },
                bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "⚝ ᗪΞᎮᗑƔ - DEV",
                    button_title: "⚝ ᗪΞᎮᗑƔ "
                },
                tap_isTarget_configuration: {
                    title: " X ",
                    description: "bomboclard",
                    canonical_url: "https://depay.dev",
                    domain: "https://depay.dev",
                    button_index: 0
                }
            }),
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "— YouTube —",
                        url: "https://youtube.com/@DepayAsli"
                    })
                },
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "— Show Fiture —",
                        sections: [
                            {
                                title: "— Public Fiture —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".allmnu"
                                }]
                            }, 
                            {
                                title: "— Contact Developer —",
                                rows: [{
                                    title: "Kontak Dev",
                                    description: "© DepayDeveloper",
                                    id: ".dev"
                                }]
                            }, 
                            {
                                title: "— Credit Script —",
                                rows: [{
                                    title: "Spesial Support",
                                    description: "© DepayDeveloper",
                                    id: ".tqto"
                                }]
                            }
                        ]
                    })
                },
                {
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Website Dev —", 
                        url: "https://depay.dev" 
                    }) 
                },
                { 
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Info Script —", 
                        url: "https://whatsapp.com/channel/0029Vb7zxXq7oQhl0tOf7417" 
                    }) 
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "— Thank you for using this bot :>",
                        flow_message_version: "3"
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Developer: depay.dev ", //jangan di hapus
                        flow_message_version: "3"    
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Spesial Support: Aaiiurs🌻", //jangan di hapus
                        flow_message_version: "3"                
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "                            © depay.dev            ",
                        flow_message_version: "3"          
                    })
                }
            ]
        }),
        contextInfo: {
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: 'New ERA',
                body: 'Depay Official',
                previewType: 'VIDEO',
                thumbnailUrl: 'https://depay.dev/levi.jpg',
                sourceUrl: 'https://depay.dev'
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    });

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: interactiveMessage
            }
        }
    }, { 
        quoted: qtext 
    });

    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 {
 await new Promise(resolve => setTimeout(resolve, 1000));
        await depayy.sendMessage(m.chat, {
            audio: { url: "https://depay.dev/depaymusik.mp3" },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: '⚝ ᗪΞᎮᗑƔ - OFFICIAL',
                    body: '© Depayy',
                    thumbnailUrl: 'https://depay.dev/foto.jpeg',
                    sourceUrl: 'https://depay.dev',
                    mediaType: 1,
                    renderLargerThumbnail: false
                },
                ...qtext.contextInfo,
                quotedMessage: qtext.message
            }
        }, { 
            quoted: qtext
        });
    }
} 


//tampilan 3
exports.MenuBotDepay3 = async (depayy, m, pushname, runtime, qtext) => {
    let timestamp = speed();
    let latensi = speed() - timestamp;
    let teks = `Welcome back, *${pushname}*.
    
Hi, I'm a bot created by \`ᗪΞᎮᗑƔ\` , This bot is specifically designed to attack, manage groups, provide useful tools, offer fun interactions, and help you create panels. Use this bot wisely; it is strictly prohibited to use these features to harm others.

—  *INFORMATION* —
Release: *2.0* 
Developer: *Depay*
GetScript: https://depay.dev
Youtube: @DepayAsli
Type: case
Visibility: Global
Trigger: .
Library: Baileys
Github: depay1221 
Telegram: @DepayAsli
Tiktok: @payeyeye_
Runtime: ${runtime(process.uptime())}
SpeedBot : ${latensi.toFixed(4)} detik

— *Command Fiture*
 .capcut *Url*
 .tiktok *Url*
 .ytmp3 *Url*
 .ytmp4 *Url*
 .igdl *Url*
 .spotify *Url*
 .mediafire *Url*
 .play *Judul*
 .gethtml *Link*
 .trackip *IP*
 .brat *Promt* 
 .depayai *Promt*
 .cekkhodam *Nama* 
 .kisahnabi *namanabi*
 .tobase64 *Teks*
 .tourl *Reply image*
 .cekidch *Url* 
 .add *Nomor*
 .kick *Tag/Reply*
 .opengc *Buka Grup*
 .closegc *Tutup Grup*
 .kudegc *Kick Allmem* 
 .hidetag *Teks*
 .tagall *Teks*
                             
— *Cpanel Fiture*
 .1gb *Username*
 .2gb *Username*
 .3gb *Username*
 .4gb *Username*
 .5gb *Username*
 .6gb *Username*
 .7gb *Username*
 .8gb *Username*
 .9gb *Username*
 .unli *Username*
 .cadmin *Username*
 .listserver *Cek Server*
 .listuser *Cek User*
 .listadmin *Cek Admin*
 .delpanel *ID*
 .deluser *ID*
 .deladmin *ID*
 .addrespanel *Nomor*
 .delrespanel *Nomor*
 .addadmin *Nomor*
 .deladmin *Nomor*

— Thank you for using this bot :>
 `  
    const headerImage = await prepareWAMessageMedia(
        { image: { url: "https://depay.dev/foto.jpeg" } },
        { upload: depayy.waUploadToServer }
    );

    const interactiveMessage = proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
            text: teks
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
            text: `\`⚝ ᗪΞᎮᗑƔ - OFFICIAL\``
        }),
        header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            hasMediaAttachment: true,
            imageMessage: headerImage.imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
                limited_time_offer: {
                    text: "⚝ ᗪΞᎮᗑƔ - OFFICIAL",
                    url: "https://depay.dev",
                    copy_code: "https://depay.dev",
                    expiration_time: Date.now() * 999
                },
                bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "⚝ ᗪΞᎮᗑƔ - DEV",
                    button_title: "⚝ ᗪΞᎮᗑƔ "
                },
                tap_isTarget_configuration: {
                    title: " X ",
                    description: "bomboclard",
                    canonical_url: "https://depay.dev",
                    domain: "https://depay.dev",
                    button_index: 0
                }
            }),
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "— YouTube —",
                        url: "https://youtube.com/@DepayAsli"
                    })
                },
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "— Show Fiture —",
                        sections: [
                            {
                                title: "— Private Fiture —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".bvgmenu"
                                }]
                            }, 
                            {
                                title: "— Contact Developer —",
                                rows: [{
                                    title: "Kontak Dev",
                                    description: "© DepayDeveloper",
                                    id: ".dev"
                                }]
                            }, 
                            {
                                title: "— Credit Script —",
                                rows: [{
                                    title: "Spesial Support",
                                    description: "© DepayDeveloper",
                                    id: ".tqto"
                                }]
                            }
                        ]
                    })
                },
                {
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Website Dev —", 
                        url: "https://depay.dev" 
                    }) 
                },
                { 
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Info Script —", 
                        url: "https://whatsapp.com/channel/0029Vb7zxXq7oQhl0tOf7417" 
                    }) 
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "— Thank you for using this bot :>",
                        flow_message_version: "3"
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Developer: depay.dev ", //jangan di hapus
                        flow_message_version: "3"    
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Spesial Support: Aaiiurs🌻", //jangan di hapus
                        flow_message_version: "3"                
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "                            © depay.dev          ",
                        flow_message_version: "3"          
                    })
                }
            ]
        }),
        contextInfo: {
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: 'New ERA',
                body: 'Depay Official',
                previewType: 'VIDEO',
                thumbnailUrl: 'https://depay.dev/levi.jpg',
                sourceUrl: 'https://depay.dev'
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    });

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: interactiveMessage
            }
        }
    }, { 
        quoted: qtext 
    });

    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 {
 await new Promise(resolve => setTimeout(resolve, 1000));
        await depayy.sendMessage(m.chat, {
            audio: { url: "https://depay.dev/depaymusik.mp3" },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: '⚝ ᗪΞᎮᗑƔ - OFFICIAL',
                    body: '© Depayy',
                    thumbnailUrl: 'https://depay.dev/foto.jpeg',
                    sourceUrl: 'https://depay.dev',
                    mediaType: 1,
                    renderLargerThumbnail: false
                },
                ...qtext.contextInfo,
                quotedMessage: qtext.message
            }
        }, { 
            quoted: qtext
        });
    }
} 