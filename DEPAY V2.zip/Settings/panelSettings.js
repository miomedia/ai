/*
Panel Settings 
*/
const egg = "15"; // Egg ID
const nestid = "5"; // Nest ID
const loc = "1"; // Location ID
const domain = ""; //Domain Panel
const apikey = ""; // PTLC
const capikey = ""; // PTLA

module.exports = { apikey, egg, domain, nestid, loc, capikey }
