const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));

global.owner = ['6283143495129'] // owner number
global.connect = true // Ubah ke false jika ingin mengkoneksikan bot menggunakan QrCode
global.url = "https://t.me/alluffystore"
global.url2 = "https://t.me/alluffytestimoni"
global.packname = "𝗢𝗰𝗵𝗼𝗕𝗼𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿"
global.author = "AlLuffy Official"
global.versi = packageJson.version